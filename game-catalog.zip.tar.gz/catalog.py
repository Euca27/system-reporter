from flask import Flask, jsonify, render_template

app = Flask(__name__)
games = [
	{"id": 1, "title": "Minecraft","platform":"Xbox","price":29.99},
	{"id": 2, "title": "Mario Kart 8 Deluxe","platform":"Nintendo Switch","price":59.99},
	{"id": 3, "title": "God of War Ragnarok","platform":"Playstation 5","price":49.99}
]
@app.route("/")
def home():
	return render_template("catalog.html",games=games)

@app.route("/games")
def catalog():
	return jsonify(games)
if __name__ == "__main__":
	app.run(host="127.0.0.1", port=5001)
